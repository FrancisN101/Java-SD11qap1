package QAP1_Java;

public class TestDate {
    
    public static void main(String[] args) {
        Date d1 = new Date(23,9,2024);
    

    System.out.println("Today's date is: " + d1 + ".");
    }
 }


















